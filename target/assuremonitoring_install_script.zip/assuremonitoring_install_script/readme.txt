This is the readme file for ZIP created for test submission.
